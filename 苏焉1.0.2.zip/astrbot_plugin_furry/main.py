from astrbot.api.star import Star, Context
from astrbot.api.event import filter, AstrMessageEvent
from astrbot.api import logger
import httpx
import tempfile
import os
import time


class FurryPlugin(Star):
    """
    随机Furry图片插件
    调用 furry.axzt.top API 获取随机Furry风格图片
    """

    # ========== 配置区（可自行修改） ==========
    # API 地址
    API_URL = "https://furry.axzt.top"
    # 请求超时时间（秒）
    TIMEOUT = 30.0
    # 临时文件保留时间（秒），超时自动清理
    TEMP_FILE_KEEP_TIME = 120
    # =========================================

    def __init__(self, context: Context):
        super().__init__(context)
        # 调用次数统计（重启清零）
        self.call_count = 0
        # 临时文件列表，用于自动清理
        self._temp_files = []

    def _cleanup_old_temp_files(self):
        """清理过期的临时文件"""
        current_time = time.time()
        remaining = []
        for filepath, create_time in self._temp_files:
            if current_time - create_time > self.TEMP_FILE_KEEP_TIME:
                try:
                    if os.path.exists(filepath):
                        os.remove(filepath)
                        logger.info(f"Furry插件：已清理临时文件 {os.path.basename(filepath)}")
                except Exception as e:
                    logger.warning(f"Furry插件：清理临时文件失败 {filepath}: {e}")
            else:
                remaining.append((filepath, create_time))
        self._temp_files = remaining

    @filter.command("furry")
    async def furry(self, event: AstrMessageEvent):
        '''获取一张随机Furry风格图片'''
        try:
            self.call_count += 1
            logger.info(f"Furry插件：正在获取随机图片...（第 {self.call_count} 次调用）")

            # 每次调用前先清理过期临时文件
            self._cleanup_old_temp_files()

            # 调用 API 获取随机图片
            async with httpx.AsyncClient(timeout=self.TIMEOUT) as client:
                response = await client.get(self.API_URL)
                response.raise_for_status()

                image_data = response.content

                # 根据 Content-Type 自动判断图片格式并选择正确后缀
                content_type = response.headers.get("content-type", "image/jpeg").lower()
                if "webp" in content_type:
                    suffix = ".webp"
                elif "png" in content_type:
                    suffix = ".png"
                elif "gif" in content_type:
                    suffix = ".gif"
                else:
                    suffix = ".jpg"

                logger.info(f"Furry插件：图片获取成功，大小 {len(image_data)} 字节，格式 {suffix}")

                # 保存到临时文件
                with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as f:
                    f.write(image_data)
                    temp_path = f.name

                # 记录临时文件，后续自动清理
                self._temp_files.append((temp_path, time.time()))

                # 返回图片结果
                yield event.image_result(temp_path)

        except httpx.TimeoutException:
            self.call_count -= 1  # 失败不计入统计
            logger.error("Furry插件：请求超时")
            yield event.plain_result("获取图片超时，请稍后再试～")
        except httpx.HTTPError as e:
            self.call_count -= 1
            logger.error(f"Furry插件：HTTP请求错误 - {str(e)}")
            yield event.plain_result("获取图片失败：网络错误，请稍后再试～")
        except Exception as e:
            self.call_count -= 1
            logger.error(f"Furry插件：未知错误 - {str(e)}")
            yield event.plain_result(f"获取图片失败：{str(e)}")

    @filter.command("兽图")
    async def furry_cn(self, event: AstrMessageEvent):
        '''获取一张随机Furry风格图片（中文命令）'''
        async for result in self.furry(event):
            yield result
