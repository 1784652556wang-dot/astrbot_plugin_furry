# AstrBot Furry 随机图片插件

一个基于 AstrBot 框架的随机Furry图片插件，调用 `furry.axzt.top` API 获取随机Furry风格图片。

## 功能

- 🖼️ 随机获取高质量Furry风格图片
- ⚡ 响应迅速，高清画质
- 🎯 支持中英文双命令
- 🛡️ 完善的错误处理机制

## 安装方法

1. 将 `astrbot_plugin_furry` 文件夹放入 AstrBot 的 `plugins` 目录
2. 重启 AstrBot
3. 插件自动加载完成

## 使用命令

| 命令 | 说明 |
|------|------|
| `/furry` | 获取一张随机Furry风格图片 |
| `/兽图` | 获取一张随机Furry风格图片（中文命令） |

## API 来源

- 接口地址：https://furry.axzt.top
- 特点：完全免费、无需鉴权、直接返回图片

## 依赖

- httpx（AstrBot 已内置）

## 版本历史

### v1.0.2
- 补充 metadata.yaml 中的 name 字段

### v1.0.1
- 修复导入路径错误（astrbot.core → astrbot.api）
- 修复插件初始化方式，添加正确的 __init__ 方法
- 优化图片返回方式，使用 yield 语法

### v1.0.0
- 初始版本
- 支持基本的随机图片获取功能
- 支持中英文双命令
- 完善的错误处理

## 作者

苏焉
