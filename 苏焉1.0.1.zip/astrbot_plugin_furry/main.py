from astrbot.api.star import Star, Context
from astrbot.api.event import filter, AstrMessageEvent
from astrbot.api import logger
import httpx


class FurryPlugin(Star):
    """
    随机Furry图片插件
    调用 furry.axzt.top API 获取随机Furry风格图片
    """

    def __init__(self, context: Context):
        super().__init__(context)

    @filter.command("furry")
    async def furry(self, event: AstrMessageEvent):
        '''获取一张随机Furry风格图片'''
        try:
            logger.info("Furry插件：正在获取随机图片...")
            
            # 调用API获取随机图片
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.get("https://furry.axzt.top")
                response.raise_for_status()
                
                image_data = response.content
                
                logger.info(f"Furry插件：图片获取成功，大小 {len(image_data)} 字节")
                
                # 保存图片到临时文件
                import tempfile
                import os
                with tempfile.NamedTemporaryFile(suffix='.jpg', delete=False) as f:
                    f.write(image_data)
                    temp_path = f.name
                
                # 返回图片结果
                yield event.image_result(temp_path)
                
                # 延迟清理临时文件（确保发送完成后再删）
                # 这里简单处理，临时文件由系统定期清理
                
        except httpx.TimeoutException:
            logger.error("Furry插件：请求超时")
            yield event.plain_result("获取图片超时，请稍后再试～")
        except httpx.HTTPError as e:
            logger.error(f"Furry插件：HTTP请求错误 - {str(e)}")
            yield event.plain_result("获取图片失败：网络错误，请稍后再试～")
        except Exception as e:
            logger.error(f"Furry插件：未知错误 - {str(e)}")
            yield event.plain_result(f"获取图片失败：{str(e)}")

    @filter.command("兽图")
    async def furry_cn(self, event: AstrMessageEvent):
        '''获取一张随机Furry风格图片（中文命令）'''
        async for result in self.furry(event):
            yield result
